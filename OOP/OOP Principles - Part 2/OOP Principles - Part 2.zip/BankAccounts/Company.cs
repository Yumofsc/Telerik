﻿namespace BankAccounts
{
    public class Company : Customer
    {
        public Company(string name, string email, int gsm)
            : base(name,email,gsm)
        { 

        }
    }
}
