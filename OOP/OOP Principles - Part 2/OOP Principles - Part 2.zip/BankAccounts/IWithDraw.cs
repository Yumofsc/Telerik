﻿namespace BankAccounts
{
    public interface IWithDraw
    {
        void withDrawMoney(decimal moneyAmount);
    }
}
