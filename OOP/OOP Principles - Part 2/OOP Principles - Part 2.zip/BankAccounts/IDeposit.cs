﻿namespace BankAccounts
{
    public interface IDeposit
    {
        void DepositeMoney(decimal moneyAmount);
        
    }
}
